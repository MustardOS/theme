#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Animal.Crossing.OS.zip"
THEME_NAME="Animal Crossing OS"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Animal Crossing OS.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Animal Crossing OS.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Animal Crossing OS.zip"
SH_NAME="Animal Crossing OS.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Animal%20Crossing%20OS.png"
CREDITS_INFO="by: Emulation Otaku" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
