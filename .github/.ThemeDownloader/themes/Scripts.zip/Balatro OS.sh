#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Balatro.OS.zip"
THEME_NAME="Balatro OS"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Balatro OS.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Balatro OS.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Balatro OS.zip"
SH_NAME="Balatro OS.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Balatro%20OS.png"
CREDITS_INFO="by: Emulation Otaku" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
