#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Initial.D.zip"
THEME_NAME="Initial D"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Initial D.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Initial D.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Initial D.zip"
SH_NAME="Initial D.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Initial%20D.png"
CREDITS_INFO="by: RYX" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
