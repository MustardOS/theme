#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Majora.zip"
THEME_NAME="Majora"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Majora.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Majora.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Majora.zip"
SH_NAME="Majora.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Majora.png"
CREDITS_INFO="by: Fabiano" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
