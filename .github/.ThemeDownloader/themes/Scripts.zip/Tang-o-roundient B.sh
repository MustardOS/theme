#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Tang-o-roundient.B.zip"
THEME_NAME="Tang-o-roundient B"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Tang-o-roundient B.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Tang-o-roundient B.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Tang-o-roundient B.zip"
SH_NAME="Tang-o-roundient B.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Tang-o-roundient%20B.png"
CREDITS_INFO="by: tiduscrying" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
