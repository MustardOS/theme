#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/Turtles.zip"
THEME_NAME="Turtles"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/Turtles.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/Turtles.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/Turtles.zip"
SH_NAME="Turtles.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/Turtles.png"
CREDITS_INFO="by: Soare M. David" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
