#!/bin/sh 
 
URL="https://github.com/MustardOS/theme/releases/latest/download/pip-muos.zip"
THEME_NAME="pip-muos"
LOCAL_ZIP_PATH="/mnt/mmc/MUOS/theme/pip-muos.zip"
LOCAL_PREVIEW="/mnt/mmc/MUOS/theme/preview/pip-muos.png"
ARCHIVE_ZIP="/mnt/mmc/ARCHIVE/pip-muos.zip"
SH_NAME="pip-muos.sh"
PREVIEW="https://raw.githubusercontent.com/MustardOS/theme/main/preview/pip-muos.png"
CREDITS_INFO="by: nonaim" 
 
rm -rf "$MUX_TEMP" /tmp/muxlog_* 
 
. "/mnt/mmc/MUOS/application/.ThemeDownloader/scripts/ThemeInstall.sh" 
 
